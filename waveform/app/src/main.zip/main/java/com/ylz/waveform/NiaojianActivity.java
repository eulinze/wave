package com.ylz.waveform;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.ylz.waveform.view.LineGraphicView;

import java.util.ArrayList;

public class NiaojianActivity extends Activity
{
	ArrayList<Double> yList;
	ArrayList<Double> y1List;
	ArrayList<Double> y2List;
	ArrayList<Double> y3List;
	ArrayList<String> xRawDatas;
	LineGraphicView tu;

	private TextView biggerTextview;
	private TextView smallTextview;


	int num=0;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.niaojian);

		biggerTextview=(TextView)findViewById(R.id.bigger_textview);
		smallTextview=(TextView)findViewById(R.id.small_textview);

		initView();

		biggerTextview.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				tu.setData(yList,y1List,y2List,y3List, xRawDatas, 8, 1);
				tu.invalidate();
			}
		});
		smallTextview.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				tu.setData(yList,y1List,y2List,y3List, xRawDatas, 16, 2);
				tu.invalidate();
			}
		});

	}
	public void initView(){
		tu = (LineGraphicView) findViewById(R.id.line_graphic);

		yList = new ArrayList<Double>();
		yList.add((double) 2.103);
		yList.add(4.05);
		yList.add(6.60);
		yList.add(3.08);
		yList.add(4.32);
		yList.add(2.0);
		yList.add(5.0);

		y1List = new ArrayList<Double>();
		y1List.add((double) 5.103);
		y1List.add(4.05);
		y1List.add(3.60);
		y1List.add(6.08);
		y1List.add(1.32);
		y1List.add(3.0);
		y1List.add(3.0);


		y2List = new ArrayList<Double>();
		y2List.add((double) 6.103);
		y2List.add(2.05);
		y2List.add(7.60);
		y2List.add(1.08);
		y2List.add(3.32);
		y2List.add(2.0);
		y2List.add(5.0);

		y3List = new ArrayList<Double>();
		y3List.add((double) 1.103);
		y3List.add(4.05);
		y3List.add(3.60);
		y3List.add(5.08);
		y3List.add(7.32);
		y3List.add(2.0);
		y3List.add(6.0);

		xRawDatas = new ArrayList<String>();
		xRawDatas.add("0");
		xRawDatas.add("1");
		xRawDatas.add("2");
		xRawDatas.add("3");
		xRawDatas.add("4");
		xRawDatas.add("5");
		xRawDatas.add("6");
		xRawDatas.add("7");
		tu.setData(yList,y1List,y2List,y3List, xRawDatas, 10, 1);
	}


}
